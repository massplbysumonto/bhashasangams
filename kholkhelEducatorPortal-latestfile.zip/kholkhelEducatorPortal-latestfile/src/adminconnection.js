// export const ADMIN_IP="http://"+process.env.REACT_APP_ADMIN_IP_ADDRESS+":"+process.env.REACT_APP_ADMIN_PORT+"/";
export const ADMIN_IP="http://localhost:3000/";