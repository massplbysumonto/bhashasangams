import SignInCard from "../components/signInCard";
const SignInPage = ()=>{

    return(<SignInCard />);

}

export default SignInPage;