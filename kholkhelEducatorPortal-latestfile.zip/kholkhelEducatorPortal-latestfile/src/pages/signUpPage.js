import SignUpCard from "../components/signUpCard";
const SignUpPage = ()=>{

    return(<SignUpCard />);

}

export default SignUpPage;