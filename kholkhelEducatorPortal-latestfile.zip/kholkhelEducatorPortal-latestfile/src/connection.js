// export const IP="http://"+process.env.REACT_APP_BACKEND_IP_ADDRESS+":"+process.env.REACT_APP_BACKEND_PORT+"/";
export const IP="http://localhost:8000/";